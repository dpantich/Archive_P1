#!/bin/bash

# Ensure the required directories exist
mkdir -p odd even

# Loop through all files in the current directory
for file in *; do
    # Check if it's a regular file (not a directory)
    if [[ -f "$file" ]]; then
        # Extract the last number before the ".bin" extension (assuming "index 0.bin" format)
        index=$(echo "$file" | grep -oE '[0-9]+(?=\.bin)')

        # Check if index was found in the filename
        if [[ -n "$index" ]]; then
            # Check if the index is even or odd and move the file accordingly
            if (( index % 2 == 0 )); then
                mv "$file" even/
            else
                mv "$file" odd/
            fi
        fi
    fi
done

echo "Files sorted: Even-indexed files are in 'even/', odd-indexed files are in 'odd/'."
